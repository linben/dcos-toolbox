# Mesosphere Multiverse

The Mesosphere Multiverse package repository is a home for experimental packages not ready for the [Universe](https://github.com/mesosphere/universe).

## Instructions

You can include the multiverse in your DCOS CLI by typing:
`dcos config prepend package.sources https://github.com/mesosphere/multiverse/archive/version-1.x.zip`
